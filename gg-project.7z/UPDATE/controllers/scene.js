class Scene extends Component {
    constructor (id="scene", className="scene", type="scene") {
        super(id, className, type);
    }
}